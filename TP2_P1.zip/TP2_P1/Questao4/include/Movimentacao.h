#ifndef MOVIMENTACAO_H
#define MOVIMENTACAO_H


class Movimentacao
{
public:
    char numeroConta[5];
    char tipoMovimentacao;
    float valorMovimentacao;


    Movimentacao();


};

#endif // MOVIMENTACAO_H
