#ifndef CONTA_H
#define CONTA_H
#include "Movimentacao.h"

class Conta
{
      private:
            char numeroConta[5];
            char nome[40];
            float saldo;

    public:
        Conta();

void LerConta();


};

#endif // CONTA_H
