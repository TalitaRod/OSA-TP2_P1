#include "Conta.h"
#include "Movimentacao.h"
#include <string.h>
#include <iostream>
#include <fstream>
#include <vector>
#include <cstring>
#include <cstdlib>
#include <cstdio>

using namespace std;

vector<Conta> contas;
vector<Movimentacao> movimentacoes;

Conta::Conta()
{
    //ctor
}

void Conta::LerConta()
{
    Conta c;
    Movimentacao m;
    float saldoAtualizadoSaque=0,saldoAtualizadoDeposito=0;

    fstream arquivoEntrada("Contas.bin",ios::in|ios::binary); /// abrindo o arquivo bin�rio para leitura.
    fstream arquivoEntrada2("Moviment.bin",ios::in|ios::binary); /// abrindo o arquivo bin�rio para leitura.


    if (arquivoEntrada.fail() || arquivoEntrada2.fail())
    {
        cout<< "Erro ao abrir o arquivo!";
    }

    cout<<"\nSaldo das contas que tem existe em comum nos arquivo contas.bin e moviment.bin, depois das transacoes: "<<endl;



    while(arquivoEntrada.read((char*)&c,sizeof(Conta)) && arquivoEntrada2.read((char*)&m,sizeof(Movimentacao)))

    {
        int numconver=atoi(c.numeroConta); /// Faz a convers�o do tipo char para um inteiro
        int numconver2=atoi(m.numeroConta); /// Faz a convers�o do tipo char para um inteiro

        if((numconver==numconver2) && (m.tipoMovimentacao=='s')) /// Se o n�mero da conta existe nos dois arquivos, e o tipo de movimenta��o � de saque,
            /// � feito a subtra��o do valor determinado.
        {
            saldoAtualizadoSaque=(c.saldo - m.valorMovimentacao);
            cout<<"\nNome: "<<c.nome<<"\nSaldo: "<<c.saldo<<"\nValor do saque: "<<m.valorMovimentacao<<"\nSaldo atualizado: "<<saldoAtualizadoSaque<<endl;

        }
        if((numconver==numconver2) && (m.tipoMovimentacao=='d')) /// Se o n�mero da conta existe nos dois arquivos, e o tipo de movimenta��o � de dep�sito,
            /// � feito a adi��o do valor determinado.
        {
            saldoAtualizadoDeposito=(c.saldo + m.valorMovimentacao);
            cout<<"\nNome: "<<c.nome<<"\nSaldo: "<<c.saldo<<"\nValor do deposito: "<<m.valorMovimentacao<<"\nSaldo atualizado: "<<saldoAtualizadoDeposito<<endl;

        }

    }

}




















