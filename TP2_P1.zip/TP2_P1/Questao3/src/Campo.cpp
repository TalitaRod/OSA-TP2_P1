#include "Campo.h"
#include <cstring>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstdio>
#include <string>
#include <stdio.h>      // para remove () e renomear ()


using namespace std;


Campo::Campo()
{
    //ctor
}

bool Campo::Remove_Item (int chave)
{
    string arqNome="auxi.txt";

    ofstream outfile(arqNome.c_str(),ios::out|ios::binary);

    Campo c;
    int cont1=0; /// Ir� ser utilizado para contabilizar a quantidade de registros que n�o possue a chave digitada igual a chave do arquivo.
    int cont2=0; /// Ir� ser utilziado para contabilizar a quantidade de registros que s�o lidos no arquivo.
    int renomeacao,retorno;



    ifstream infile("Arq.txt",ios::in|ios::binary); /// abrindo o arquivo
    if (infile.fail())
    {
        cout<< "Erro ao abrir o arquivo!"<<endl;
    }


    while(infile.read((char*)&c,sizeof(Campo)))
    {
        if(chave==c.chave)
        {
        }
        else
        {
            cont1++;

            outfile.write((char*)&c,sizeof(Campo));
            retorno=true;
        }
        cont2++;
    }

    if(cont1==cont2) /// Se a quantidade de registros que n�o possue a chave digitada, for igual a quantidade de registros lidos,
        /// significa que a chave digitada, n�o existe no arquivo.
    {
        cout<<"Esta chave nao existe no arquivo!"<<endl;
        retorno=false;
    }



    infile.close();
    outfile.close();

    remove("Arq.txt"); /// Remove o arquivo original
    renomeacao=rename("auxi.txt","Arq.txt"); /// O arquivo que � auxiliar, � renomeado.

    return retorno;
}




