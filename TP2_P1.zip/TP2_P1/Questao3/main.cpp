#include "Campo.h"
#include <iostream>
#include <fstream>

using namespace std;


int main()
{
    Campo c;
    int chave=0,retorno=0;


    cout<<"Lista de Exercicios: QUESTAO 3"<<endl;

    cout<<"\nDigite uma chave: ";
    cin>>chave;

    retorno=c.Remove_Item(chave);

    if(retorno!=0)
    {
        cout<<"Existe esta chave no arquivo"<<endl;
    }


    return 0;
}
