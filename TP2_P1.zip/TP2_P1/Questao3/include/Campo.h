#ifndef CAMPO_H
#define CAMPO_H


class Campo
{
private:
    int chave;
    char dado2[30];
    float dado3[4];

public:
    Campo();
    bool Remove_Item (int chave);
void CriaArquivo();
};

#endif // CAMPO_H
