#ifndef MODELO_H
#define MODELO_H
#include <string>
using namespace std;
class Modelo
{


public:
    char nome[30];
    char sexo[1];
    char corOlhos[1];
    float altura;
    float peso;

    Modelo();
    void Print();
    void Separacao();
    string Convert(char *a,int size);



};

#endif // MODELO_H
