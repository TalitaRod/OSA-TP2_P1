#include "Modelo.h"
#include <iostream>

using namespace std;

int main()
{
    Modelo m;

    cout<<"Lista de Exercicios: QUESTAO 5"<<endl;


    m.Separacao();
    return 0;
}
