#include "Modelo.h"
#include <vector>
#include <string.h>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <cstdlib>

using namespace std;

vector<Modelo> modelos;

#define TAM_LINHA 255

Modelo::Modelo()
{
    //ctor
}

/// Fun��o para converter uma variavel char em string.
string Modelo::Convert(char *a,int size)
{

    int i=0;

    string s= "";
    for(i=0; i<size; i++)
    {
        s=s+a[i];
    }
    return s;
}

/// Fun��o que vai ler o arquivo e faz a grava��o em dois arquivos separados de acordo com  sexo do modelo.
void Modelo::Separacao()
{
    int i=0;
    char linha[TAM_LINHA+1];
    string sexo2="f";
    string sexo1="m";
    string nome;
    string sexo;
    string corOlhos;
    Modelo m;

    ifstream infile("Dados.txt"); /// abrindo o arquivo
    if (infile.fail())
    {
        cout<< "Erro ao abrir o arquivo!";
    }

    ofstream outfile1("ModSexoMasculino.txt",ios::out|ios::binary);
    if(outfile1.fail() )
    {
        cout<<"Erro ao criar arquivo";
    }

    ofstream outfile2("ModSexoFeminino.txt",ios::out|ios::binary);
    if(outfile2.fail() )
    {
        cout<<"Erro ao criar arquivo";
    }

    nome=m.Convert(m.nome,30);
    sexo=m.Convert(m.sexo,1);
    corOlhos=m.Convert(m.corOlhos,1);

    infile.getline(linha,TAM_LINHA);
    while(!infile.eof())
    {
        infile.getline(linha, TAM_LINHA);

        nome = strtok(linha, ";");
        sexo = strtok(NULL, ";");

        corOlhos = strtok(NULL, ";");
        m.altura = atof(strtok(NULL, ";"));
        m.peso = atof(strtok(NULL, ";"));

        modelos.push_back(m);

        if(sexo.compare(sexo1) != 1)
        {

            cout<<nome<<" "<<sexo<<" "<<corOlhos<<" "<<m.altura<<" "<<m.peso<<" "<<endl;
            outfile1.write((char*)&m,sizeof(Modelo));

        }

        if(sexo.compare(sexo2) != 1)
        {
            cout<<nome<<" "<<sexo<<" "<<corOlhos<<" "<<m.altura<<" "<<m.peso<<" "<<endl;
            outfile2.write((char*)&m,sizeof(Modelo));

        }

    }
}







