#include "Aluno.h"
#include <iostream>

using namespace std;

int main()
{
    Aluno alu;

    cout<<"Lista de Exercicios: QUESTAO 1\n"<<endl;

    alu.LerArquivo();






        return 0;
}
