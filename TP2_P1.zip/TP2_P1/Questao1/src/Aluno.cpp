#include "Aluno.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <iomanip>

#define TAM_LINHA 255

using namespace std;


vector<Aluno> alunos;

Aluno::Aluno()
{
    //ctor
}


void Aluno::LerArquivo()
{
    Aluno a;
    float media=0,total=0;

    cout<<"LEGENDA CONCEITO: \nExelente - media >= 8.5 \nBom - media >= 7.0 e < 8.5 \nPreocupante - media < 7.0\n"<<endl;

    ifstream infile("Alunos.bin",ios::in|ios::binary); /// abrindo o arquivo
    if (infile.fail())
    {
        cout<< "Erro ao abrir o arquivo!";
    }
    else
    {
        while(infile.read((char*)&a,sizeof(Aluno)))
        {

            total=a.nota1+a.nota2+a.nota3;
            media=total/3;

            if(media >= 8)
            {
                cout << fixed << setprecision(2);
                cout<<"Media: "<<media<<endl;
                cout<<"Excelente  - ";
                cout<<a.matricula<<" "<<a.nome<<" "<<a.nota1<<"/"<<a.nota2<<"/"<<a.nota3<<endl;
            }

            if ((media >= 7.0) && (media< 8.5))
            {
                cout << fixed << setprecision(2);
                cout<<"Media: "<<media<<endl;
                cout<<"Bom  - ";
                cout<<a.matricula<<" "<<a.nome<<" "<<a.nota1<<"/"<<a.nota2<<"/"<<a.nota3<<endl;
            }

            if(media < 7.0)
            {
                cout << fixed << setprecision(2);
                cout<<"Media: "<<media<<endl;
                cout<<"Preocupante  - ";
                cout<<a.matricula<<" "<<a.nome<<" "<<a.nota1<<"/"<<a.nota2<<"/"<<a.nota3<<endl;
            }
            cout<<endl;
        }
    }

    infile.close();

}



