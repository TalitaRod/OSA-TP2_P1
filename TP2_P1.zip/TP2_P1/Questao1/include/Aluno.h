#ifndef ALUNO_H
#define ALUNO_H
#include <string>
using namespace std;
class Aluno
{

private:
    char matricula[3];
    char nome[30];
    float nota1;
    float nota2;
    float nota3;
public:

    Aluno();
    void LerArquivo();



};

#endif // ALUNO_H
