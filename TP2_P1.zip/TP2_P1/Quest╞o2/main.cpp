#include "Candidato.h"
#include <iostream>

using namespace std;

int main()
{
    cout<<"Lista de Exercicios: QUESTAO 2"<<endl;
    Candidato can;

    can.LerArquivo();
    can.ContagemVencedor();

    /// Visualizar os dados do arquivo
    //can.Print();

    return 0;
}
