#include "Candidato.h"
#include <vector>
#include <string.h>
#include <iostream>
#include <fstream>

#define TAM_LINHA 255

using namespace std;

vector<Candidato> candidato;


Candidato::Candidato()
{
    //ctor
}

/// Set
void Candidato::set_codIdentificacap(int codIdentificacao)
{
    this->codIdentificacao = codIdentificacao;
}

/// Get
int Candidato::get_codIdentificacap()
{
    return codIdentificacao;
}

void Candidato::LerArquivo()
{
    int i,cont=0;
    char linha[TAM_LINHA+1];


    ifstream infile("Votos.txt"); /// abrindo o arquivo
    if (infile.fail())
    {
        cout<<"\nErro ao abrir o arquivo!"<<endl;
    }
    else
    {
        cout<<"\nArquivo com o nome 'Votos' no formato 'txt' lido com sucesso!"<<endl;
    }

    infile.getline(linha,TAM_LINHA);
    while(!infile.eof())
    {
        Candidato c;
        infile.getline(linha, TAM_LINHA);
        c.codIdentificacao = atof(strtok(linha, " "));

        candidato.push_back(c);
    }

    infile.close();

}

void Candidato::Print()
{
    for(int i=0; i<candidato.size(); i++)
    {
        Candidato c = candidato[i];
        cout<<c.codIdentificacao<<endl;

    }
}

void Candidato::ContagemVencedor()
{
    int cont1=0,cont2=0,cont3=0,cont4=0,cont5=0,contNulo=0, maior=0,menor=0;
    for(int i=0; i<candidato.size(); i++)
    {
        Candidato c = candidato[i];
        if(c.codIdentificacao==1)
        {
            cont1++;

            maior=cont1;

            menor=cont1;

        }
        else if (c.codIdentificacao==2)
        {
            cont2++;
            if(cont2>maior)
            {
                maior=cont2;
            }
            if(cont2<menor)
            {
                menor=cont2;

            }
        }
        else if (c.codIdentificacao==3)
        {
            cont3++;
            if(cont3>maior)
            {
                maior=cont3;

            }
            if(cont3<menor)
            {
                menor=cont3;

            }
        }
        else if (c.codIdentificacao==4)
        {
            cont4++;
            if(cont4>maior)
            {
                maior=cont4;

            }
            if(cont4<menor)
            {
                menor=cont4;

            }
        }
        else if (c.codIdentificacao==5)
        {
            cont5++;
            if(cont5>maior)
            {
                maior=cont5;

            }
            if(cont5<menor)
            {
                menor=cont5;

            }
        }
        else if (c.codIdentificacao != (1 && 2 && 3 && 4 && 5))
        {
            contNulo++;
        }
    }

    /// Verificando a o candidato que recebeu a quantidade maior de votos.

    if (maior == cont1)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MAIOR DE VOTOS!!! \nCodigo de identificacao: 1, a quantidade de votos: "<<cont1<<endl;
    }
    if (maior == cont2)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MAIOR DE VOTOS!!! \nCodigo de identificacao: 2, a quantidade de votos: "<<cont2<<endl;
    }
    if (maior == cont3)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MAIOR DE VOTOS!!! \nCodigo de identificacao: 3, a quantidade de votos: "<<cont3<<endl;
    }
    if (maior == cont4)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MAIOR DE VOTOS!!! \nCodigo de identificacao: 4, a quantidade de votos: "<<cont4<<endl;
    }
    if (maior == cont5)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MAIOR DE VOTOS!!! \nCodigo de identificacao: 5, a quantidade de votos: "<<cont5<<endl;
    }

    /// Verificando o candidato que recebeu a quantidade menor de votos
    if (menor == cont1)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MENOR DE VOTOS!!! \nCodigo de identificacao: 1, a quantidade de votos: "<<cont1<<endl;
    }
    if (menor == cont2)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MENOR DE VOTOS!!! \nCodigo de identificacao: 2, a quantidade de votos: "<<cont2<<endl;
    }
    if (menor == cont3)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MENOR DE VOTOS!!! \nCodigo de identificacao: 3, a quantidade de votos: "<<cont3<<endl;
    }
    if (menor == cont4)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MENOR DE VOTOS!!! \nCodigo de identificacao: 4, a quantidade de votos: "<<cont4<<endl;
    }
    if (menor == cont5)
    {
        cout<<"\nCANDIDATO COM A QUANTIDADE MENOR DE VOTOS!!! \nCodigo de identificacao: 5, a quantidade de votos: "<<cont5<<endl;
    }


    cout<<"\nA quantidade de votos nulos sao: "<<contNulo<<endl;

    cout<<"\nCandidato 1: "<<cont1<<" votos.";
    cout<<"\nCandidato 2: "<<cont2<<" votos.";
    cout<<"\nCandidato 3: "<<cont3<<" votos.";
    cout<<"\nCandidato 4: "<<cont4<<" votos.";
    cout<<"\nCandidato 5: "<<cont5<<" votos.";

}
