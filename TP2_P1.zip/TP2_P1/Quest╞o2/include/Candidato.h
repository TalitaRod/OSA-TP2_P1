#ifndef CANDIDATO_H
#define CANDIDATO_H
#include <fstream>
#include <cstdio>
#include <cstdlib>
#include <iostream>

class Candidato
{
private:
    int codIdentificacao;

public:
    Candidato();
    void set_codIdentificacap(int);
    int get_codIdentificacap();
    void LerArquivo();
    void Print();
    void ContagemVencedor();

};

#endif // CANDIDATO_H
